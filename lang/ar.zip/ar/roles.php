<?php

declare(strict_types=1);

return [
    'admin' => 'Administrator',
    'user-manager' => 'User Manager',
    'registered-user' => 'Registered User',
];
