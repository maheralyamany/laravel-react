<?php

declare(strict_types=1);

return [
    'rating_saved' => 'Rating saved successfully',
    'rating_failed' => 'Failed to save rating',
    'logout_successful' => 'Logout successful',
    'logout_failed' => 'Failed to logout',
];
