<?php

declare(strict_types=1);

return [
    'login' => 'Login',
    'logout' => 'Logout',
    'dashboard' => 'Dashboard',
];
