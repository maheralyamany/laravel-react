<?php

declare(strict_types=1);

return [
    'login' => 'تسجيل الدخول',
    'logout' => 'تسجيل الخروج',
    'dashboard' => 'لوحة القيادة',
];


