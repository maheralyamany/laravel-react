<?php

declare(strict_types=1);

return [
    'admin' => 'المسؤول',
    'user-manager' => 'مدير المستخدمين',
    'registered-user' => 'مستخدم مسجل',
];


