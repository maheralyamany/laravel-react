<?php

declare(strict_types=1);

return [
    'rating_saved' => 'تم حفظ التقييم بنجاح',
    'rating_failed' => 'فشل حفظ التقييم',
    'logout_successful' => 'تم تسجيل الخروج بنجاح',
    'logout_failed' => 'فشل تسجيل الخروج',
];


